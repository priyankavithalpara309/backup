$(document).ready(function () {
    $(".menu-btn").click(function () {
        $('nav>.ul-content').toggle();
    });
    $(".slick-slider").slick({
        dots: true,
        Infinity: true,
        speed: 800,
        slideToshow: 1
    });
});

$(document).ready(function () {

    $('#container #tabs li[id^="tab"]').click(function () {
        var targetID = $(this).attr('href');
        var target = $('#content #' + targetID);

        $('#container #tabs li').removeClass('active');
        $(this).addClass('active');

        $('#content li[id^="tab"]').hide();
        target.show();

    });

    var width = $('#slideshow li').width();

    $('#slideshow li:last-child').prependTo($(this).parent('ul'));

    $('#container ul#content li div#prev').click(function () {
        var targ = $(this).parent('li').find('ul');

        targ.animate({ 'left': '+=200px' }, 300, function () {
            targ.find('li:last-child').prependTo(targ);
            targ.css('left', '');
        });
    });

    $('#container ul#content li div#nex').click(function () {
        var targ = $(this).parent('li').find('ul');
        targ.animate({ 'left': '-=200px' }, 300, function () {
            targ.find('li:first-child').appendTo(targ);
            targ.css('left', '');
        });
    });

})