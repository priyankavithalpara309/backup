import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-information1',
  templateUrl: './information1.component.html',
  styleUrls: ['./information1.component.scss']
})
export class Information1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
