import { ClickoutsideDirective } from './clickoutside.directive';

describe('ClickoutsideDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickoutsideDirective();
    expect(directive).toBeTruthy();
  });
});
