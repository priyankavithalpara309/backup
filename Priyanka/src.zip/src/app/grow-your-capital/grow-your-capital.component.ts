import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grow-your-capital',
  templateUrl: './grow-your-capital.component.html',
  styleUrls: ['./grow-your-capital.component.scss']
})
export class GrowYourCapitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
