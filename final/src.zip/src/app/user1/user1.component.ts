import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UrlHandlingStrategy } from '@angular/router';
import { from } from 'rxjs';
import { UserService } from '../services/user.service';

class ImageSnippet {
  constructor(public src: string, public file: File) {}
}


@Component({
  selector: 'app-user1',
  templateUrl: './user1.component.html',
  styleUrls: ['./user1.component.css']
})
export class User1Component implements OnInit {
  
  username: string | any;
  selectedFile: any = [];
  emailid:any;
  phone:any;
  CounteryName: any;
  

  frmuser=new FormGroup({
    username:new FormControl('',[Validators.required,Validators.pattern('[a-zA-Z]+$')]),
    emailid:new FormControl('',[Validators.required,Validators.email]),
    phone:new FormControl('',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
    CounteryName:new FormControl(),
    selectedFile:new FormControl()

  }) 

  // get username(){
  //   return this.frmuser.get('username')
  // }

  // get emailid(){
  //   return this.frmuser.get('emailid')
  // }

  // get phone(){
  //   return this.frmuser.get('phone')
  // }

  
  file: string='';  
  user_data: any;
  dropdownCountry: any;
  country1: any;  
  searchedKeyword: any;

  e_name: any;
  e_emailid: any;
  e_id: any;
  e_country_nm: any;
  e_phone: any;
  _ID: any;
  // image1:any;

  

  edituser = "none";
  url = 'http://localhost:4000/public/';    
  
  constructor(private adduserdata: UserService) { }

  ngOnInit(): void {
    this.adduserdata.showAllUser().subscribe((data) => {
      console.log(data);
      this.user_data = data;
    });

    this.adduserdata.showAllCountry().subscribe((data) => {
      console.log(data);
      this.dropdownCountry = data;
    });
  }
  onFileInput(fileInput:any){        
    console.log(fileInput)
    const reader = new FileReader();
    const file: File = fileInput.files[0];

   reader.addEventListener('load', (event: any) => {
      this.selectedFile = new ImageSnippet(event.target.result, file);
     console.log(this.selectedFile.file)
     
     
   });
   reader.readAsDataURL(file);
    
  }

  adduser(data:any) {

   console.log(this.frmuser);
    const formdata = new FormData();   

    this.username=this.frmuser.controls['username'].value;
    this.emailid=this.frmuser.controls['emailid'].value;
    this.phone=this.frmuser.controls['phone'].value;
    
    formdata.append("UserName", this.username);     
    // formdata.append("Email",this.emailid);
    // formdata.append("PhoneNumber",this.phone);
    // formdata.append("countryId",this.CounteryName);
    formdata.append('image', this.selectedFile);    
    console.log(formdata);
    this.adduserdata.addUser(formdata).subscribe((data) => {
        console.log(data);
      })


    // console.log(formdata);
    // this.adduserdata.addUser(this.frmuser).subscribe((data) => {
    //   console.log(data);
    // })
    // console.log(this.username, this.emailid, this.phone, this.CounteryName, this.fileName);
    // this.adduserdata.addUser({ UserName: this.username, countryId: this.CounteryName, Email: this.emailid, PhoneNumber: this.phone, image:  this.fileName}).subscribe((data) => {
    //   console.log(data);
    // })
    // this.adduserdata.addUser(_id,{UserName:this.username,countryId:this.CounteryName,Email:this.emailid,PhoneNumber:this.phone,image:this.fileName}).subscribe((data)=>{
    //   console.log(data);
    // })
  }
 
  
  

  Changed(event: any) {
    console.log(event.target.value);
    this.CounteryName = event.target.value;
    console.log(this.CounteryName);
  }


}