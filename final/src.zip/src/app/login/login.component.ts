import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators} from '@angular/forms';
import {UserService} from '../services/user.service';
import {Router} from '@angular/router'


@Component({

  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  constructor(private userlogin:UserService, private router:Router) { }      
  // UserName:any;

  username:any
  pass:any
  loginForm: NgForm | undefined

  login(){
    console.log(this.username);    
    this.userlogin.login({UserName: this.username, Password: this.pass}).subscribe((data)=>{      
          console.log(data);          
          this.router.navigate(["menu"])          
      })    
  }

  ngOnInit(): void {  
   
  }

          

}
