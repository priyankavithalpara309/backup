import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import {VehicleTypeComponent} from './vehicle-type/vehicle-type.component';
import {CountryComponent} from './country/country.component';
import {CityComponent} from './city/city.component';
import {VehiclePricingComponent} from './vehicle-pricing/vehicle-pricing.component';
import {UserComponent} from './user/user.component';
import {DriverComponent} from './driver/driver.component';
import {User1Component} from './user1/user1.component';


const routes: Routes = [  
  {path:"", redirectTo:"login", pathMatch:"full"},
  {path:"login",component:LoginComponent},
  {path:'menu',component:MenuComponent},
  {path:'vehicle',component:VehicleTypeComponent},
  {path:'country',component:CountryComponent},
  {path:'city',component:CityComponent},
  {path:'vehiclePricing',component:VehiclePricingComponent},
  {path:'user',component:UserComponent},
  {path:'driver',component:DriverComponent},
  {path:'user1',component:User1Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
