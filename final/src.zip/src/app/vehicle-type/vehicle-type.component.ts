import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {UserService} from '../services/user.service'

@Component({
  selector: 'app-vehicle-type',
  templateUrl: './vehicle-type.component.html',
  styleUrls: ['./vehicle-type.component.css']
})
export class VehicleTypeComponent implements OnInit {
  
  vehicle_data: any;
  constructor(private vehicle:UserService) { }

  vehicle_name:any;
  // vehicle_image:any;
  vehicleForm: NgForm | undefined  

  url='http://localhost:4000/public/';
 
  fileName: string = '';    
  fileName1:string="Upload Type Image";
  onFileInput(event:any){    
    this.fileName = event.target.files[0];        
    this.fileName1 = event.target.files[0].name;        
    console.log(this.fileName);
  }

  addVehicle(){
    console.log(this.fileName,this.vehicle_name);
    const formdata = new FormData();
    formdata.append('VehicleName', this.vehicle_name);
    formdata.append('image', this.fileName);     
    console.log(formdata);
    this.vehicle.vehicle_add(formdata).subscribe((data)=>{
      console.log(data);
    })

    
  }

  ngOnInit(): void {
    this.vehicle.showAllVehicle().subscribe((data)=>{
      console.log(data);
      this.vehicle_data=data;
    });
  }


}
