import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UrlHandlingStrategy } from '@angular/router';
import { UserService } from '../services/user.service';


class ImageSnippet {
  constructor(public src: string, public file: File) {}
}


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})

export class UserComponent implements OnInit {

  fileName: string='';
  username: any;
  emailid: any;
  phone: any;
  user_data: any;
  dropdownCountry: any;
  country1: any;
  CounteryName: any;
  searchedKeyword: any;

  e_name: any;
  e_emailid: any;
  e_id: any;
  e_country_nm: any;
  e_phone: any;
  _ID: any;
  // image1:any;

  edituser = "none";
  url = 'http://localhost:4000/public/';  
  selectedFile: any;
  
  constructor(private adduserdata: UserService) { }

  ngOnInit(): void {
    this.adduserdata.showAllUser().subscribe((data) => {
      console.log(data);
      this.user_data = data;
    });

    this.adduserdata.showAllCountry().subscribe((data) => {
      console.log(data);
      this.dropdownCountry = data;
    });
  }

  // onFileInput(fileInput:any){        
  //   console.log(fileInput)
  //   const reader = new FileReader();
  //   const file: File = fileInput.files[0];

  //  reader.addEventListener('load', (event: any) => {
  //     this.selectedFile = new ImageSnippet(event.target.result, file);
  //    console.log(this.selectedFile.file)
     
     
  //  });
  //  reader.readAsDataURL(file);
  // }

  onFileInput(event:any){        
    this.fileName = event.target.files[0];
    console.log(this.fileName);

  }


  adduser() {       
    const formdata = new FormData();
    formdata.append('UserName', this.username);
    formdata.append('countryId', this.CounteryName);
    formdata.append('Email', this.emailid);
    formdata.append('PhoneNumber', this.phone);
    formdata.append('image', this.fileName);           

    console.log(formdata);
    this.adduserdata.addUser(formdata).subscribe((data) => {
      console.log(data);
    })

    // console.log(this.username, this.emailid, this.phone, this.CounteryName, this.fileName);
    // this.adduserdata.addUser({ UserName: this.username, countryId: this.CounteryName, Email: this.emailid, PhoneNumber: this.phone, image:  this.fileName}).subscribe((data) => {
    //   console.log(data);
    // })

    // this.adduserdata.addUser(_id,{UserName:this.username,countryId:this.CounteryName,Email:this.emailid,PhoneNumber:this.phone,image:this.fileName}).subscribe((data)=>{
    //   console.log(data);
    // })
  }
 
  
  

  Changed(event: any) {
    console.log(event.target.value);
    this.CounteryName = event.target.value;
    console.log(this.CounteryName);
  }

  edituserdata(data: any) {
    this.edituser = "block";
    console.log(data);
    this.e_id = data._id;
    this.e_name = data.UserName;
    this.e_emailid = data.Email;
    // this.image1=data.image;
    this.e_country_nm=data.countryId._id;
    this.e_phone = data.PhoneNumber;
    this.fileName = data.image;

    console.log(this.e_country_nm);
    
    // console.log(this.fileName);
  }

  removedata(data: any) {
    this._ID = data._id;
    console.log(this._ID);
    this.adduserdata.deleteuser(this._ID).subscribe((data) => {
      console.log(data);
    })
  }

  edit() {
    const formdata = new FormData();
    formdata.append('UserName', this.e_name);
    formdata.append('countryId', this.CounteryName);
    formdata.append('Email', this.e_emailid);
    formdata.append('PhoneNumber', this.e_phone);
    formdata.append('image', this.fileName);           
    
    console.log(this.e_id, this.e_name, this.e_emailid, this.e_phone, this.CounteryName, this.fileName);
    this.adduserdata.updateuser(this.e_id, formdata).subscribe((data) => {
      console.log(data);
    })
    this.close();
  }

  close() {
    this.edituser = "none";
  }

  public formData1: any = {};

  submit(formData1: NgForm) { }
}
