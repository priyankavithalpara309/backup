import { trigger,state,style,animate,transition} from '@angular/animations';

export const trans = [
    trigger('openClose',[      
        state('closed',style({
          display:'none',        
          height:0,
          opacity:0        
        })),
        state('open',style({     
          display:'block',          
          opacity:1,                
        })),              
        transition('open<=>closed',[
          style({ display: 'block' }),         
          animate('0.4s')        
        ]),        
      ]),
  
      trigger('rotatedState',[
          state('closed', style({ transform: 'rotate(0)' })),
          state('open', style({ transform: 'rotate(-180deg)' })),
          transition('closed => open', animate('900ms ease-out')),
          transition('open => closed', animate('400ms ease-in'))
      ])
      
];
  