import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { VehicleTypeComponent } from './vehicle-type/vehicle-type.component';
import { CountryComponent } from './country/country.component';
import {Ng2SearchPipeModule} from 'ng2-search-filter';
import { CityComponent } from './city/city.component';
import { VehiclePricingComponent } from './vehicle-pricing/vehicle-pricing.component';
import { UserComponent } from './user/user.component';
import { EditComponent } from './edit/edit.component';
import { DriverComponent } from './driver/driver.component';
import { User1Component } from './user1/user1.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    VehicleTypeComponent,
    CountryComponent,
    CityComponent,
    VehiclePricingComponent,
    UserComponent,
    EditComponent,
    DriverComponent,
    User1Component
  ],
  imports: [
    BrowserModule,    
    BrowserAnimationsModule,
    ReactiveFormsModule,
    NgbModule,
    AppRoutingModule,
    HttpClientModule,    
    FormsModule,
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
