import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  loginapi='http://192.168.0.105:4000/api/login'; //post api
  vehicle_create='http://192.168.0.105:4000/api/vehicle/create'; //post api
  allvehicle='http://192.168.0.105:4000/api/vehicle/allVehicle'; //get api
  country='https://restcountries.com/v2/all'; //get country api
  country_Create='http://192.168.0.105:4000/api/countery/create'; //post api;
  allcountry='http://192.168.0.105:4000/api/countery'; //get api
  adduser='http://192.168.0.105:4000/api/user/addUser'; //post api 
  allUser='http://192.168.0.105:4000/api/user/getuser/alluser'; //get api
  edituser='http://192.168.0.105:4000/api/user/updateUser/'; //post api
  remove='http://192.168.0.105:4000/api/user/remove/'; //post api
  addDriver='http://192.168.0.105:4000/api/driver/create'//post api
  allDriver='http://192.168.0.105:4000/api/driver/getDrivers' //get api
  editDriver='http://192.168.0.105:4000/api/driver/update/' //post api
  removeDriver='http://192.168.0.105:4000/api/driver/remove/' //post api
  assignVehicle='http://192.168.0.105:4000/api/driver/assignVehicle/' //post api

  constructor(private http:HttpClient) { }

  login(data:any){
    console.log(data);
    
    return this.http.post(this.loginapi,data);
  }

  vehicle_add(data:any){
    console.log(data);    
    return this.http.post(this.vehicle_create,data);
  }

  showAllVehicle(){
    return this.http.get(this.allvehicle);
  }

  add_country(data:any){
    console.log(data);
    return this.http.post(this.country_Create,data);
  }

  showAllCountry(){
    return this.http.get(this.allcountry);
  }

  countryData(){
    return this.http.get(this.country);
  }

  addUser(data:any){
    console.log(data);
    return this.http.post(this.adduser,data);
  }

  showAllUser(){
    return this.http.get(this.allUser);
  }

  updateuser(url1:any,data:any){
    console.log(data,url1);
    return this.http.put(this.edituser+url1,data);
  }

  deleteuser(url2:any){
    console.log(url2);
    return this.http.delete(this.remove+url2);
  }

  adddriver(data:any){
    console.log(data);
    return this.http.post(this.addDriver,data);
  }

  showAllDriver(){
    return this.http.get(this.allDriver);
  }

  assignvehicle(data:any,data1:any){
    console.log(data,data1);    
    return this.http.put(this.assignVehicle+data,data1);
  }

  updatedriver(url3:any,data:any){
    console.log(data,url3);
    return this.http.put(this.editDriver+url3,data);
  }

  deletedriver(url_d:any){
    console.log(url_d);
    return this.http.delete(this.removeDriver+url_d);
  }

}
