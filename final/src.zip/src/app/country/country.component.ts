import { Component, OnInit } from '@angular/core';
import {UserService} from '../services/user.service';


@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {
  country_data: any;

  constructor(private addcountrySev:UserService) { }
  
  ngOnInit(): void {
    this.addcountrySev.showAllCountry().subscribe((data)=>{
      console.log(data);
      this.country_data=data;      
    });
  }

  country="none";
  CounteryName:any;
  country1:any;
  a1:any;    
  currencycode:any;
  countrycode:any;
  currencysign:any;
  flag:any;
  
  data2:[]=[];  
  img:any;
  sign:any;
  phone:any;
  curr_code:any;

  search_nm:any;

  searchedKeyword: any;

  card="none";  

  addCountry(){
    this.country="block";    
    this.addcountrySev.countryData().subscribe((count)=>{
      // console.warn("count",count);
      this.country1=count;
      console.log(this.country1);
    })
  }

  closePopup(){
    this.country="none";
  }  

  Changed(event:any) {      
    console.log(event.target.value);      
    this.CounteryName = event.target.value;
    console.log(this.CounteryName);

    const count = this.country1.filter((country: { name: any; }) => country.name === this.CounteryName);
      console.log(count);

      this.currencycode=count[0].currencies[0].code;
      this.countrycode=count[0].callingCodes[0];
      this.currencysign=count[0].currencies[0].symbol;
      this.flag=count[0].flags.png;
      console.log(this.currencycode,this.currencysign,this.countrycode,this.flag);   
  }

  add(){
    this.country="none";    
    this.data2=this.CounteryName;    
    this.img=this.flag;
    this.sign=this.currencysign;
    this.phone=this.countrycode;
    this.curr_code=this.currencycode
    
    console.log(this.data2,this.img,this.sign,this.phone,this.curr_code);
    this.addcountrySev.add_country({CounteryName:this.data2,CounteryCode:this.phone,CurrencyCode:this.curr_code,Sign:this.img,CurrencySign:this.sign}).subscribe((data)=>{
      console.log(data);
    })
  }

  

  // search(event:any){
  //   console.log(this.search_nm);    
  //   this.addcountrySev.showAllCountry().subscribe((data)=>{
  //     console.log(data);
  //     this.country_data=data;      
  //   });
     
  // }

}
