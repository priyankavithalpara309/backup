import { Component, OnInit } from '@angular/core';
import {animation} from '@angular/animations';
import { trigger,state,style,animate,transition} from '@angular/animations';
import { trans } from '../animation';

@Component({
  selector: 'app-menu',  
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  animations:[trans]  
})
export class MenuComponent implements OnInit {

  constructor() { }

  isOpen = false;  
  isOpen1 = false
  menu_arrow: any = false;
  menu_arrow1:any =false;

  toggle() {
    this.isOpen = !this.isOpen;
    // this.isOpen1 = !this.isOpen1;
    this.menu_arrow = (this.menu_arrow === 'open' ? 'closed' : 'open');
    // this.menu_arrow1 = (this.menu_arrow1 === 'open' ? 'closed' : 'open');
  }

  toggle1() {    
    this.isOpen1 = !this.isOpen1;    
    this.menu_arrow1 = (this.menu_arrow1 === 'open' ? 'closed' : 'open');
  }


  ngOnInit(): void {
  }

}
