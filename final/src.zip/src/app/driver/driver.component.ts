import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {UserService} from '../services/user.service';

@Component({
  selector: 'app-driver',
  templateUrl: './driver.component.html',
  styleUrls: ['./driver.component.css']
})
export class DriverComponent implements OnInit {

  fileName:any;
  editdriver="none";
  assign_vehicle="none";
  drivername:any;
  driveremail:any;
  phone:any;
  driver_data:any;
  CounteryName: any;
  dropdownCountry:any;
  vehicle_data:any;
  img:any;

  d_name:any;
  d_emailid:any;
  d_phone:any;
  d_id: any;
  e_country_nm: any;
  
  constructor(private driverser:UserService) { }

  ngOnInit(): void {
    this.driverser.showAllDriver().subscribe((data)=>{
      console.log(data);
      this.driver_data=data;      
    });

    this.driverser.showAllCountry().subscribe((data)=>{
      console.log(data);
      this.dropdownCountry=data;      
    });    
  }

  onFileInput(event:any){    
    this.fileName = event.target.files[0];        
    console.log(this.fileName);    
  }

  Changed(event:any) {      
    console.log(event.target.value);      
    this.CounteryName = event.target.value;
    console.log(this.CounteryName);
  }

  adddriver(){
    console.log(this.drivername,this.driveremail,this.phone,this.CounteryName,this.fileName);

    const formdata = new FormData();
    formdata.append('DriverName', this.drivername);
    formdata.append('Email', this.driveremail);    
    formdata.append('PhoneNumber', this.phone);
    formdata.append('countryId', this.CounteryName);
    formdata.append('image', this.fileName);           

    console.log(formdata);
    this.driverser.adddriver(formdata).subscribe((data)=>{
      console.log(data);
    })
  }
  
  EditDriverdata(data:any){
    this.editdriver="block";
    console.log(data);
    this.d_id=data._id;
    this.d_name=data.DriverName;
    this.d_emailid=data.Email;
    this.d_phone=data.PhoneNumber;  
    this.fileName=data.image;
    this.e_country_nm=data.countryId._id;
    console.log(this.e_country_nm);
    
  }

  AssignDriverdata(){
    this.assign_vehicle="block";
    this.driverser.showAllVehicle().subscribe((data)=>{
      console.log(data);
      this.vehicle_data=data;
    });
  }

  assignVehicle(data:any,data1:any){  
    console.log(data);      
    console.log(data1);      
    this.driverser.assignvehicle(data._id,{ServiceType:data1._id,OnlineStatus:'approved'}).subscribe((data)=>{
      console.log(data);
    })
    this.close();
  }

  removeDriver(data:any){
    this.driverser.deletedriver(data._id).subscribe((data)=>{
      console.log(data);
    })
  }

  close(){
    this.assign_vehicle="none";
    this.editdriver="none";
  }

  edit(){
    console.log(this.d_id,this.d_name,this.d_emailid,this.d_phone,this.CounteryName,this.fileName);

    const formdata = new FormData();
    formdata.append('DriverName', this.d_name);
    formdata.append('Email', this.d_emailid);    
    formdata.append('PhoneNumber', this.d_phone);
    formdata.append('countryId', this.CounteryName);
    formdata.append('image', this.fileName);
        
    this.driverser.updatedriver(this.d_id,formdata).subscribe((data)=>{
      console.log(data);
    })
    this.close();
  }

  public formData1:any={};

  submit(formData1:NgForm){}
}
